

#
# Imports
#
import os
import sys
 

xbmc.executebuiltin("Notification(Test 4, Execution successfull, but should not be executable)")