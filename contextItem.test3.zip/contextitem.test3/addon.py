

#
# Imports
#
import os
import sys
 

xbmc.executebuiltin("Notification(Test 3, Execution successfull)")