

#
# Imports
#
import os
import sys
 

xbmc.executebuiltin("Notification(Test 1, Execution successfull)")