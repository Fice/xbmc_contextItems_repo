

#
# Imports
#
import os
import sys
 

xbmc.executebuiltin("Notification(Test 2, Execution successfull)")