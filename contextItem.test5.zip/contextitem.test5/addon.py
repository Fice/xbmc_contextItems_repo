

#
# Imports
#
import os
import sys
 

xbmc.executebuiltin("Notification(Test 5, Execution successfull)")